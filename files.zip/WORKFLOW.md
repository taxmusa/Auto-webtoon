# WORKFLOW.md - 워크플로우 상세 스펙

> 이 문서는 세무 웹툰 자동화 시스템의 전체 워크플로우를 상세히 정의합니다.
> 구현 시 이 문서를 참고하여 로직을 작성합니다.

---

## 1. 전체 워크플로우 개요

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           전체 워크플로우                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  [시작] ──▶ [모드 선택] ──▶ [정보 수집] ──▶ [스토리 생성]               │
│                │                                   │                    │
│         ┌─────┴─────┐                              ▼                    │
│         │           │                     ┌──────────────┐              │
│      [자동]      [수동]                   │  씬 검토 UI  │ ◀── 1차 체크 │
│         │           │                     │  (편집/확정) │              │
│         ▼           ▼                     └──────┬───────┘              │
│   [키워드 입력]  [직접 입력]                      │                      │
│         │           │                            ▼                      │
│         ▼           │                     [이미지 생성]                 │
│   [분야 자동 감지]  │                            │                      │
│         │           │                            ▼                      │
│         ▼           │                     ┌──────────────┐              │
│   [정보 수집]  ◀────┘                     │ 이미지 검토  │ ◀── 2차 체크 │
│                                           │ (재생성/확정)│              │
│                                           └──────┬───────┘              │
│                                                  │                      │
│                                                  ▼                      │
│                                           [텍스트 오버레이]             │
│                                                  │                      │
│                                                  ▼                      │
│                                           [최종 확인]                   │
│                                                  │                      │
│                                                  ▼                      │
│                                           [Instagram 발행]              │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 2. 단계별 상세

### 2.1 Step 1: 모드 선택

**입력**: 사용자 선택
**출력**: 모드 타입 (AUTO / MANUAL)

```python
class WorkflowMode(Enum):
    AUTO = "auto"      # 키워드 기반 자동 생성
    MANUAL = "manual"  # 직접 입력
```

**UI 표시**:
```
┌─────────────────────────────────────┐
│  어떤 방식으로 시작할까요?           │
│                                     │
│  [🔄 자동 모드]    [✏️ 수동 모드]   │
│  키워드만 입력하면   직접 내용을     │
│  AI가 자동 생성     입력합니다      │
└─────────────────────────────────────┘
```

---

### 2.2 Step 2: 키워드 입력 및 분야 감지 (자동 모드)

**입력**: 키워드 문자열
**출력**: 분야 정보 + 정보 수집 방식

#### 2.2.1 분야 자동 감지 로직

```python
SPECIALIZED_FIELDS = {
    "세무": ["세금", "소득세", "부가세", "법인세", "종합소득", "원천징수", "세무사", "국세청"],
    "법률": ["법률", "소송", "계약", "변호사", "판례", "민법", "형법"],
    "노무": ["노동", "근로", "퇴직금", "4대보험", "노무사", "해고", "임금"],
    "회계": ["회계", "재무제표", "분개", "결산", "감사", "회계사"],
    "부동산정책": ["부동산", "양도세", "취득세", "임대사업자", "분양", "청약"]
}

def detect_field(keyword: str) -> FieldInfo:
    """키워드에서 분야 자동 감지"""
    keyword_lower = keyword.lower()
    
    for field, keywords in SPECIALIZED_FIELDS.items():
        if any(kw in keyword_lower for kw in keywords):
            return FieldInfo(
                field=field,
                requires_legal_verification=True,
                data_collection_method="specialized"
            )
    
    return FieldInfo(
        field="일반",
        requires_legal_verification=False,
        data_collection_method="general_search"
    )
```

#### 2.2.2 사용자 확인 UI

```
┌─────────────────────────────────────────────────────┐
│  키워드: "종합소득세 신고"                            │
│                                                     │
│  📋 AI 분석 결과:                                   │
│  ┌─────────────────────────────────────────────┐   │
│  │ 분야: 세무 ✓                                 │   │
│  │ 기준: 2025년                                 │   │
│  │ 법령 검증: 필요 ✓                            │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
│  [확인] [분야 변경 ▼]                               │
└─────────────────────────────────────────────────────┘
```

---

### 2.3 Step 3: 정보 수집

**입력**: 키워드 + 분야 정보
**출력**: 수집된 정보 (SourceMaterial)

#### 2.3.1 전문 분야 정보 수집

```python
async def collect_specialized_info(keyword: str, field: str) -> SourceMaterial:
    """전문 분야 정보 수집 - 법령 검증 포함"""
    
    # 1. 웹 검색으로 최신 정보 수집
    web_results = await web_search(keyword)
    
    # 2. 법령/규정 DB 검색 (분야별)
    if field == "세무":
        legal_info = await search_tax_law(keyword)
    elif field == "법률":
        legal_info = await search_legal_db(keyword)
    # ... 기타 분야
    
    # 3. 정보 통합 및 검증
    verified_info = await verify_and_merge(web_results, legal_info)
    
    return SourceMaterial(
        topic=keyword,
        field=field,
        content=verified_info,
        sources=web_results.sources + legal_info.sources,
        verified=True,
        collection_date=datetime.now()
    )
```

#### 2.3.2 일반 분야 정보 수집

```python
async def collect_general_info(keyword: str) -> SourceMaterial:
    """일반 분야 정보 수집 - 웹 검색"""
    
    web_results = await web_search(keyword)
    
    return SourceMaterial(
        topic=keyword,
        field="일반",
        content=web_results.content,
        sources=web_results.sources,
        verified=False,
        collection_date=datetime.now()
    )
```

---

### 2.4 Step 4: 스토리 생성

**입력**: SourceMaterial + 설정
**출력**: Story (씬 목록)

#### 2.4.1 씬 개수 및 시리즈 분할 추천

```python
def recommend_scene_count(content_length: int, complexity: str) -> SceneRecommendation:
    """콘텐츠 분량에 따른 씬 개수 추천"""
    
    # 기본 추천 로직
    if complexity == "simple":
        base_scenes = 6
    elif complexity == "medium":
        base_scenes = 10
    else:  # complex
        base_scenes = 15
    
    # 시리즈 분할 계산 (인스타 최대 10장)
    if base_scenes <= 10:
        series_split = [base_scenes]
    elif base_scenes <= 20:
        half = base_scenes // 2
        series_split = [half, base_scenes - half]
    else:
        # 3개 이상 시리즈
        series_split = calculate_optimal_split(base_scenes, max_per_series=10)
    
    return SceneRecommendation(
        total_scenes=base_scenes,
        series_count=len(series_split),
        scenes_per_series=series_split,
        message=f"총 {base_scenes}개 씬, {len(series_split)}개 시리즈로 나누는 걸 추천해요"
    )
```

#### 2.4.2 스토리 생성 프롬프트

```python
STORY_GENERATION_PROMPT = """
당신은 전문적인 웹툰 스토리 작가입니다.

[입력 정보]
주제: {topic}
분야: {field}
수집된 정보: {source_content}

[설정]
씬 개수: {scene_count}
스타일: {style}
캐릭터: 질문자({questioner_type}), 전문가({expert_type})

[규칙]
1. 각 씬은 다음 형식으로 작성:
   - 장면 설명 (배경, 상황)
   - 캐릭터 대사 (최대 20자)
   - 나레이션 (최대 30자, 선택)

2. 한 씬에 말풍선은 최대 2개

3. 스토리 구조:
   - 도입: 문제 상황 제시
   - 전개: 전문가 설명
   - 마무리: 핵심 정리

4. 대화체로 친근하게 작성

[출력 형식]
JSON 형식으로 출력:
{{
  "title": "제목",
  "scenes": [
    {{
      "scene_number": 1,
      "scene_description": "장면 설명",
      "dialogues": [
        {{"character": "민지", "text": "대사"}},
        {{"character": "세무사", "text": "대사"}}
      ],
      "narration": "나레이션 (선택)"
    }}
  ]
}}
"""
```

---

### 2.5 Step 5: 씬 검토 UI (1차 체크포인트)

**입력**: Story
**출력**: 확정된 Story

#### 2.5.1 씬 검토 데이터 모델

```python
@dataclass
class SceneReview:
    scene_number: int
    scene_description: str
    dialogues: List[Dialogue]
    narration: Optional[str]
    status: str  # "pending" | "approved" | "needs_edit"
    warnings: List[str]  # 콘텐츠 밀도 경고 등
```

#### 2.5.2 콘텐츠 밀도 검증

```python
def validate_scene_density(scene: Scene) -> List[str]:
    """씬의 콘텐츠 밀도 검증"""
    warnings = []
    
    # 대사 길이 체크
    for dialogue in scene.dialogues:
        if len(dialogue.text) > 20:
            warnings.append(
                f"대사가 너무 깁니다 ({len(dialogue.text)}자 → 20자 권장): "
                f"'{dialogue.text[:20]}...'"
            )
    
    # 말풍선 개수 체크
    if len(scene.dialogues) > 2:
        warnings.append(
            f"말풍선이 너무 많습니다 ({len(scene.dialogues)}개 → 2개 권장)"
        )
    
    # 나레이션 길이 체크
    if scene.narration and len(scene.narration) > 30:
        warnings.append(
            f"나레이션이 너무 깁니다 ({len(scene.narration)}자 → 30자 권장)"
        )
    
    return warnings
```

#### 2.5.3 씬 검토 액션

```python
class SceneReviewAction(Enum):
    APPROVE = "approve"           # 이 씬 확정
    EDIT = "edit"                 # 직접 수정
    REGENERATE = "regenerate"     # AI 재생성
    CHANGE_STYLE = "change_style" # 스타일 변경 (예: 칠판 스타일로)
    DELETE = "delete"             # 씬 삭제
    ADD_BEFORE = "add_before"     # 앞에 씬 추가
    ADD_AFTER = "add_after"       # 뒤에 씬 추가
    MOVE = "move"                 # 순서 변경
```

---

### 2.6 Step 6: 이미지 생성

**입력**: 확정된 Story + 설정
**출력**: 씬별 이미지 URL 목록

#### 2.6.1 이미지 생성 프롬프트 구성

```python
def build_image_prompt(scene: Scene, settings: ImageSettings) -> str:
    """씬 정보를 바탕으로 이미지 생성 프롬프트 구성"""
    
    base_style = {
        "webtoon": "korean webtoon style, clean lines, vibrant colors",
        "card_news": "modern infographic style, clean design, professional",
        "simple": "minimalist design, solid background, clean typography"
    }
    
    sub_style = {
        "ghibli": "studio ghibli inspired, soft colors, dreamy atmosphere",
        "romance": "soft pastel colors, warm lighting, emotional",
        "business": "professional, corporate style, clean"
    }
    
    prompt = f"""
    {base_style[settings.style]}
    {sub_style.get(settings.sub_style, "")}
    
    Scene: {scene.scene_description}
    
    Characters:
    - {scene.dialogues[0].character}: speaking
    
    DO NOT include any text, speech bubbles, or letters in the image.
    The text will be added separately.
    
    Aspect ratio: {settings.aspect_ratio}
    """
    
    return prompt
```

#### 2.6.2 배치 이미지 생성

```python
async def generate_images_batch(
    scenes: List[Scene], 
    settings: ImageSettings
) -> List[GeneratedImage]:
    """여러 씬의 이미지를 배치로 생성"""
    
    results = []
    
    for scene in scenes:
        prompt = build_image_prompt(scene, settings)
        
        if settings.model == "dall-e-3":
            image = await generate_dalle_image(prompt, settings)
        elif settings.model == "imagen":
            image = await generate_imagen_image(prompt, settings)
        
        results.append(GeneratedImage(
            scene_number=scene.scene_number,
            image_url=image.url,
            prompt_used=prompt,
            status="generated"
        ))
    
    return results
```

---

### 2.7 Step 7: 이미지 검토 UI (2차 체크포인트)

**입력**: 생성된 이미지 목록
**출력**: 확정된 이미지 목록

#### 2.7.1 이미지 검토 액션

```python
class ImageReviewAction(Enum):
    APPROVE = "approve"         # 이 이미지 확정
    REGENERATE = "regenerate"   # 재생성 (같은 프롬프트)
    REGENERATE_NEW = "regenerate_new"  # 재생성 (프롬프트 수정)
    UPLOAD_CUSTOM = "upload_custom"    # 직접 이미지 업로드
```

---

### 2.8 Step 8: 텍스트 오버레이

**입력**: 확정된 이미지 + Story
**출력**: 텍스트가 합성된 최종 이미지

> 상세 내용은 TEXT_OVERLAY.md 참조

---

### 2.9 Step 9: 캡션 자동 생성 (3차 체크포인트)

**입력**: Story + 분야 정보
**출력**: 캡션 (훅 + 본문 + 팁 + 해시태그)

#### 2.9.1 캡션 구조

```python
@dataclass
class InstagramCaption:
    hook: str              # 훅 문장 (첫 줄, 클릭 유도)
    body: str              # 본문 캡션
    expert_tip: str        # 세무사/전문가 Tip
    hashtags: List[str]    # 해시태그 15~20개
    
    def to_string(self) -> str:
        """인스타 발행용 전체 캡션 문자열"""
        hashtag_str = " ".join(self.hashtags)
        return f"""{self.hook}

{self.body}

💡 {self.expert_tip}

{hashtag_str}"""
```

#### 2.9.2 캡션 생성 프롬프트

```python
CAPTION_GENERATION_PROMPT = """
당신은 인스타그램 마케팅 전문가입니다.

[입력 정보]
주제: {topic}
분야: {field}
스토리 요약: {story_summary}
핵심 정보: {key_points}

[생성 규칙]

1. 훅 문장 (첫 줄)
   - 이모지로 시작
   - 호기심 유발 또는 문제 제기
   - 15자 내외

2. 본문 캡션
   - 친근한 말투
   - 스토리 내용 요약
   - CTA 포함 (저장, 공유 유도)
   - 3~5문장

3. 전문가 Tip
   - 핵심 정보 1줄 요약
   - 실용적인 조언
   - 20자 내외

4. 해시태그
   - 15~20개
   - 대형 태그 (10만+ 게시물) 5개
   - 중형 태그 (1만~10만) 10개
   - 소형 태그 (1000~1만) 5개

[출력 형식]
JSON 형식으로 출력:
{{
  "hook": "🔥 훅 문장",
  "body": "본문 캡션",
  "expert_tip": "전문가 팁",
  "hashtags": ["#태그1", "#태그2", ...]
}}
"""
```

#### 2.9.3 해시태그 생성 로직

```python
async def generate_hashtags(topic: str, field: str) -> List[str]:
    """주제와 분야 기반 해시태그 생성"""
    
    # 분야별 기본 해시태그
    FIELD_BASE_HASHTAGS = {
        "세무": ["#세무사", "#세금", "#절세", "#세금정보", "#국세청"],
        "법률": ["#변호사", "#법률상담", "#법률정보", "#계약서"],
        "노무": ["#노무사", "#근로기준법", "#노동법", "#4대보험"],
        "회계": ["#회계사", "#재무제표", "#회계정보", "#결산"],
        "부동산정책": ["#부동산", "#부동산정책", "#양도세", "#취득세"]
    }
    
    # AI로 주제 기반 해시태그 생성
    topic_hashtags = await ai_generate_topic_hashtags(topic)
    
    # 기본 + 주제 해시태그 결합
    base = FIELD_BASE_HASHTAGS.get(field, [])
    all_tags = list(set(base + topic_hashtags))
    
    # 15~20개로 조정
    return all_tags[:20] if len(all_tags) > 20 else all_tags
```

#### 2.9.4 캡션 검토 UI

```
┌─────────────────────────────────────────────────────────────────┐
│  📝 캡션 검토                                        [전체 재생성] │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  🔥 훅 문장 (첫 줄)                                    [재생성]  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 🔥 종합소득세 신고, 이것만 알면 끝!                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  📝 본문 캡션                                          [재생성]  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 매년 5월이면 찾아오는 종소세 신고 시즌!                   │   │
│  │ 어떻게 해야 할지 막막하셨죠?                             │   │
│  │                                                         │   │
│  │ 오늘 웹툰에서 핵심만 쏙쏙 알려드릴게요 👀                │   │
│  │ 저장해두고 신고할 때 꺼내보세요!                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  💡 세무사 Tip                                         [재생성]  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 신고 기한 놓치면 가산세! 5월 31일까지 꼭 신고하세요!      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  #️⃣ 해시태그 (18개)                           [재생성] [+ 추가]  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ #종합소득세 ✕  #세금신고 ✕  #절세팁 ✕  #세무사 ✕        │   │
│  │ #5월세금 ✕  #소득세 ✕  #세금정보 ✕  #직장인세금 ✕       │   │
│  │ #프리랜서세금 ✕  #개인사업자 ✕  #종소세 ✕  ...          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ─────────────────────────────────────────────────────────────  │
│  📱 미리보기                                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 🔥 종합소득세 신고, 이것만 알면 끝!                       │   │
│  │                                                         │   │
│  │ 매년 5월이면 찾아오는 종소세 신고 시즌!                   │   │
│  │ 어떻게 해야 할지 막막하셨죠?                             │   │
│  │ ...더보기                                               │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│              [이전]                    [캡션 확정 → 최종 확인]    │
└─────────────────────────────────────────────────────────────────┘
```

---

### 2.10 Step 10: 최종 확인 및 발행

**입력**: 최종 이미지 + 발행 설정
**출력**: Instagram 발행 결과

#### 2.9.1 발행 데이터 준비

```python
@dataclass
class PublishData:
    images: List[str]           # 이미지 URL 목록
    caption: str                # 본문
    hashtags: List[str]         # 해시태그
    scheduled_time: Optional[datetime]  # 예약 시간
    series_info: Optional[SeriesInfo]   # 시리즈 정보
```

#### 2.9.2 해시태그 자동 생성

```python
async def generate_hashtags(topic: str, field: str) -> List[str]:
    """주제와 분야 기반 해시태그 자동 생성"""
    
    # 기본 해시태그
    base_tags = ["#세무", "#세금정보", "#절세팁"]
    
    # 주제 기반 해시태그
    topic_tags = await ai_generate_hashtags(topic)
    
    # 분야별 추천 해시태그
    field_tags = FIELD_HASHTAGS.get(field, [])
    
    # 중복 제거 및 정리
    all_tags = list(set(base_tags + topic_tags + field_tags))
    
    # 인스타 해시태그 제한 (30개)
    return all_tags[:30]
```

> 상세 발행 내용은 INSTAGRAM_API.md 참조

---

## 3. 에러 처리

### 3.1 단계별 에러 처리

```python
class WorkflowError(Exception):
    def __init__(self, step: str, message: str, recoverable: bool = True):
        self.step = step
        self.message = message
        self.recoverable = recoverable

# 에러 처리 예시
try:
    images = await generate_images_batch(scenes, settings)
except RateLimitError:
    raise WorkflowError(
        step="image_generation",
        message="API 호출 제한에 도달했습니다. 잠시 후 다시 시도해주세요.",
        recoverable=True
    )
except InvalidPromptError as e:
    raise WorkflowError(
        step="image_generation",
        message=f"이미지 생성 프롬프트 오류: {e}",
        recoverable=True
    )
```

### 3.2 재시도 로직

```python
@retry(max_attempts=3, delay=2)
async def generate_image_with_retry(prompt: str, settings: ImageSettings):
    """재시도 로직이 포함된 이미지 생성"""
    return await generate_dalle_image(prompt, settings)
```

---

## 4. 상태 관리

### 4.1 워크플로우 상태

```python
class WorkflowState(Enum):
    INITIALIZED = "initialized"
    COLLECTING_INFO = "collecting_info"
    GENERATING_STORY = "generating_story"
    REVIEWING_SCENES = "reviewing_scenes"
    GENERATING_IMAGES = "generating_images"
    REVIEWING_IMAGES = "reviewing_images"
    OVERLAYING_TEXT = "overlaying_text"
    READY_TO_PUBLISH = "ready_to_publish"
    PUBLISHED = "published"
    ERROR = "error"
```

### 4.2 세션 데이터 저장

```python
@dataclass
class WorkflowSession:
    session_id: str
    state: WorkflowState
    mode: WorkflowMode
    keyword: Optional[str]
    field_info: Optional[FieldInfo]
    source_material: Optional[SourceMaterial]
    story: Optional[Story]
    images: List[GeneratedImage]
    final_images: List[str]
    publish_data: Optional[PublishData]
    created_at: datetime
    updated_at: datetime
```

---

## 변경 이력

| 날짜 | 버전 | 변경 내용 |
|------|------|----------|
| 2026-02-06 | 1.0.0 | 초기 워크플로우 스펙 작성 |
