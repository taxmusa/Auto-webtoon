# IMAGE_EDIT_STAGE.md - 이미지 편집 단계 상세 설계

> **프로젝트**: Tax Webtoon Auto-Generator  
> **버전**: 1.0.0  
> **최종 수정일**: 2026-02-09  
> **목적**: 이미지 생성 후 ~ 텍스트 오버레이 전, 이미지를 편집/확정하는 단계의 UI·로직·데이터 흐름 전체 설계

---

## 1. 이 단계가 필요한 이유

### 1.1 워크플로우 상 위치

```
① 시작 → ② 정보수집 → ③ 스토리(씬 검토)
    → ④ 스타일 선택 + 샘플 미리보기
    → ⑤ 이미지 생성
    → ⑥ 이미지 편집 ← ★ 이 문서의 범위 ★
    → ⑦ 텍스트 오버레이 (Pillow로 한글 말풍선 합성)
    → ⑧ 캡션 검토 → ⑨ 발행
```

### 1.2 왜 텍스트 오버레이 전에 편집해야 하는가

- 텍스트 합성 후 이미지를 바꾸면 **말풍선 위치/크기를 다시 잡아야** 함
- 원본(글자 없는 깨끗한 이미지) 상태에서 톤/색감/구도를 확정하는 게 효율적
- 대사 수정은 텍스트 오버레이 단계에서 무료로 가능하므로, 이 단계에서는 **그림 자체**에만 집중

### 1.3 핵심 기능 요약

| 기능 | 설명 | 비용 |
|------|------|------|
| **전체 톤 조절** | 자연어 명령으로 전체 씬의 색감/채도/밝기 일괄 변경 | 단순 보정: 무료(Pillow) / AI 재생성: 유료 |
| **씬별 이미지 확인** | 왼쪽 씬 정보 + 오른쪽 이미지 미리보기 카드 | 무료 |
| **개별 이미지 재생성** | 특정 씬만 프롬프트 수정 후 재생성 | API 1회 비용 |
| **프롬프트 수동 편집** | 이미지 프롬프트를 직접 수정하여 재생성 | API 1회 비용 |
| **직접 이미지 업로드** | AI 생성 대신 사용자 이미지 사용 | 무료 |
| **모든 씬 확정** | 전체 ✓ 후 다음 단계 진행 | 무료 |

---

## 2. 전체 UI 레이아웃

```
┌─────────────────────────────────────────────────────────────────────┐
│  🎨 세무 웹툰 자동 생성기                            [설정] [도움말] │
├─────────────────────────────────────────────────────────────────────┤
│  ① 시작 → ② 정보 → ③ 스토리 → ④ 스타일 → ⑤ 이미지생성            │
│  → [⑥ 이미지편집] → ⑦ 텍스트 → ⑧ 캡션 → ⑨ 발행                   │
│         ▲ 현재 단계                                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─── 전체 톤 조절 ──────────────────────────────────────────────┐ │
│  │                                                               │ │
│  │  💬 명령 입력: [채도를 높이고 따뜻한 느낌으로 바꿔줘          ] │ │
│  │                                                    [전체 적용] │ │
│  │                                                               │ │
│  │  빠른 조절:                                                   │ │
│  │  [채도↑] [채도↓] [밝기↑] [밝기↓] [따뜻하게] [차갑게]          │ │
│  │  [선명하게] [부드럽게] [대비↑] [대비↓]                        │ │
│  │                                                               │ │
│  │  ⓘ 단순 색감 조절은 무료 / AI 재생성이 필요한 변경은 비용 안내│ │
│  │                                              [전체 원복]       │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌─── 진행 상태: 2/6 확정 ───────────────────────────────────────┐ │
│  │  ■■□□□□ (33%)                                                 │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ═══════════════════════════════════════════════════════════════════ │
│                                                                     │
│  ┌─── 장면 1: 남편의 선언 ───────────────────────────────────────┐ │
│  │                                                               │ │
│  │  ┌─── 씬 정보 (왼쪽) ────┐  ┌─── 이미지 (오른쪽) ─────────┐ │ │
│  │  │                       │  │                              │ │ │
│  │  │ 나레이션:             │  │  ┌──────────────────────┐   │ │ │
│  │  │ 1년 전 남편이         │  │  │                      │   │ │ │
│  │  │ 선언했죠.             │  │  │   [생성된 이미지]     │   │ │ │
│  │  │                       │  │  │   (말풍선 없는 원본)  │   │ │ │
│  │  │ 대사:                 │  │  │                      │   │ │ │
│  │  │ 나 개발자가 될 거야!  │  │  └──────────────────────┘   │ │ │
│  │  │                       │  │                              │ │ │
│  │  │ 이미지 프롬프트:      │  │     [이미지 재생성]          │ │ │
│  │  │ 웹툰 스타일, 거실     │  │     [프롬프트 수정]          │ │ │
│  │  │ 배경, 하얀 고양이가.. │  │     [이미지 업로드]          │ │ │
│  │  │                       │  │     [✓ 확정]                 │ │ │
│  │  │ 생성: 5초             │  │                              │ │ │
│  │  │ [편집]                │  │  상태: ⏳ 미확정              │ │ │
│  │  └───────────────────────┘  └──────────────────────────────┘ │ │
│  │                                                               │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌─── 장면 2 ────────────────────────────────────────────────────┐ │
│  │  ... (동일 카드 구조)                                         │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ... (장면 3~N)                                                     │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│         [← 이전: 이미지 생성]     [다음: 텍스트 오버레이 →]         │
│  ⓘ 모든 씬을 확정해야 다음 단계로 진행할 수 있습니다                │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 3. 전체 톤 조절 (상단 영역)

### 3.1 두 가지 처리 경로

사용자 명령을 분석하여 **무료 처리 가능**과 **AI 재생성 필요**를 자동 구분.

```python
class ToneAdjustmentType(Enum):
    PILLOW_FREE = "pillow_free"       # Pillow로 무료 처리 가능
    AI_REGENERATE = "ai_regenerate"   # AI 재생성 필요 (비용 발생)

# Pillow로 무료 처리 가능한 조절
PILLOW_ADJUSTABLE = {
    "채도": "saturation",         # PIL.ImageEnhance.Color
    "밝기": "brightness",         # PIL.ImageEnhance.Brightness
    "대비": "contrast",           # PIL.ImageEnhance.Contrast
    "선명도": "sharpness",        # PIL.ImageEnhance.Sharpness
    "따뜻하게": "warm_filter",    # 색상 채널 조정 (R↑, B↓)
    "차갑게": "cool_filter",      # 색상 채널 조정 (R↓, B↑)
    "세피아": "sepia_filter",
    "흑백": "grayscale",
}

# AI 재생성이 필요한 변경 (비용 발생)
AI_REQUIRED_CHANGES = {
    "구도 변경": "캐릭터 위치나 포즈 변경",
    "배경 교체": "사무실 → 카페 등",
    "캐릭터 표정 변경": "기쁨 → 진지 등",
    "스타일 변경": "웹툰 → 지브리 등",
    "오브젝트 추가/제거": "소품 변경",
}
```

### 3.2 자연어 명령 분석

```python
async def analyze_tone_command(user_command: str) -> ToneAnalysis:
    """사용자 명령을 분석하여 처리 방법 결정"""
    
    pillow_keywords = {
        "채도": ("saturation", 1.3),
        "밝게": ("brightness", 1.2),
        "어둡게": ("brightness", 0.8),
        "선명": ("sharpness", 1.5),
        "따뜻": ("warm_filter", 1.2),
        "차갑": ("cool_filter", 1.2),
        "대비": ("contrast", 1.3),
        "부드럽": ("sharpness", 0.7),
    }
    
    for keyword, (effect, value) in pillow_keywords.items():
        if keyword in user_command:
            return ToneAnalysis(
                type=ToneAdjustmentType.PILLOW_FREE,
                effect=effect,
                value=value,
                cost=0,
                message=f"✅ 무료로 적용 가능합니다 ({effect})"
            )
    
    # 키워드 매칭 안 되면 AI에게 분류 요청
    classification = await classify_with_ai(user_command)
    
    if classification.requires_regeneration:
        scene_count = len(current_scenes)
        estimated_cost = scene_count * model_config.cost_per_image
        return ToneAnalysis(
            type=ToneAdjustmentType.AI_REGENERATE,
            cost=estimated_cost,
            message=f"⚠️ AI 재생성이 필요합니다 (예상 비용: ${estimated_cost:.2f}, {scene_count}장)"
        )
    
    return ToneAnalysis(type=ToneAdjustmentType.PILLOW_FREE, cost=0)
```

### 3.3 Pillow 톤 조절 코드

```python
from PIL import Image, ImageEnhance
import numpy as np

class ToneAdjuster:
    """이미지 톤 조절 (Pillow 기반, 무료)"""
    
    def adjust_saturation(self, image: Image, factor: float) -> Image:
        return ImageEnhance.Color(image).enhance(factor)
    
    def adjust_brightness(self, image: Image, factor: float) -> Image:
        return ImageEnhance.Brightness(image).enhance(factor)
    
    def adjust_contrast(self, image: Image, factor: float) -> Image:
        return ImageEnhance.Contrast(image).enhance(factor)
    
    def adjust_sharpness(self, image: Image, factor: float) -> Image:
        return ImageEnhance.Sharpness(image).enhance(factor)
    
    def apply_warm_filter(self, image: Image, intensity: float = 1.2) -> Image:
        arr = np.array(image, dtype=np.float32)
        arr[:, :, 0] = np.clip(arr[:, :, 0] * intensity, 0, 255)  # R↑
        arr[:, :, 2] = np.clip(arr[:, :, 2] / intensity, 0, 255)  # B↓
        return Image.fromarray(arr.astype(np.uint8))
    
    def apply_cool_filter(self, image: Image, intensity: float = 1.2) -> Image:
        arr = np.array(image, dtype=np.float32)
        arr[:, :, 2] = np.clip(arr[:, :, 2] * intensity, 0, 255)  # B↑
        arr[:, :, 0] = np.clip(arr[:, :, 0] / intensity, 0, 255)  # R↓
        return Image.fromarray(arr.astype(np.uint8))
    
    def apply_batch(self, images: list[Image], adjustments: list[dict]) -> list[Image]:
        """전체 이미지에 동일한 조절 일괄 적용"""
        results = []
        for img in images:
            adjusted = img.copy()
            for adj in adjustments:
                method = getattr(self, f"adjust_{adj['effect']}", None) or \
                         getattr(self, f"apply_{adj['effect']}", None)
                if method:
                    adjusted = method(adjusted, adj.get('value', 1.0))
            results.append(adjusted)
        return results
```

### 3.4 전체 톤 조절 UI 인터랙션

```
사용자: "좀 더 채도를 높이고 싶어"
                ↓
시스템: 키워드 "채도" 감지 → Pillow 처리 가능
                ↓
┌───────────────────────────────────────────┐
│ ✅ 무료로 적용 가능합니다 (채도 +30%)     │
│                                           │
│ 미리보기:                                 │
│ ┌────────────┐  →  ┌────────────┐        │
│ │ 씬1 (전)   │     │ 씬1 (후)   │        │
│ └────────────┘     └────────────┘        │
│                                           │
│ [전체 적용] [강도 조절 ─●───── 130%]      │
│ [취소]                                    │
└───────────────────────────────────────────┘

사용자: "배경을 카페로 바꿔줘"
                ↓
시스템: AI 분류 → 재생성 필요
                ↓
┌───────────────────────────────────────────┐
│ ⚠️ AI 재생성이 필요합니다                  │
│ 예상 비용: $0.30 (6장 × $0.05/장)        │
│                                           │
│ [전체 재생성 ($0.30)] [취소]              │
└───────────────────────────────────────────┘
```

---

## 4. 씬별 편집 카드

### 4.1 데이터 모델

```python
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

class ImageEditStatus(Enum):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    REGENERATING = "regenerating"

@dataclass
class SceneEditCard:
    scene_number: int
    scene_title: str
    narration: Optional[str]
    dialogue: Optional[str]
    dialogue_character: Optional[str]
    image_prompt: str
    generation_time_seconds: float
    original_image_path: str          # AI 생성 원본
    current_image_path: str           # 현재 표시 중 (톤 조절 후일 수 있음)
    tone_adjusted: bool = False
    status: ImageEditStatus = ImageEditStatus.PENDING
    image_history: list[str] = field(default_factory=list)
    prompt_history: list[str] = field(default_factory=list)

@dataclass
class ImageEditStage:
    project_id: str
    scenes: list[SceneEditCard]
    global_tone_adjustments: list[dict] = field(default_factory=list)
    
    @property
    def confirmed_count(self) -> int:
        return sum(1 for s in self.scenes if s.status == ImageEditStatus.CONFIRMED)
    
    @property
    def all_confirmed(self) -> bool:
        return self.confirmed_count == len(self.scenes)
    
    @property
    def progress_percent(self) -> int:
        return int(self.confirmed_count / len(self.scenes) * 100) if self.scenes else 0
```

### 4.2 씬별 액션

```python
class SceneEditAction(Enum):
    CONFIRM = "confirm"
    UNCONFIRM = "unconfirm"
    REGENERATE = "regenerate"
    EDIT_PROMPT = "edit_prompt"
    UPLOAD_IMAGE = "upload_image"
    UNDO = "undo"

async def handle_scene_action(scene: SceneEditCard, action: SceneEditAction, payload=None):
    if action == SceneEditAction.CONFIRM:
        scene.status = ImageEditStatus.CONFIRMED
    
    elif action == SceneEditAction.UNCONFIRM:
        scene.status = ImageEditStatus.PENDING
    
    elif action == SceneEditAction.REGENERATE:
        scene.image_history.append(scene.current_image_path)
        scene.status = ImageEditStatus.REGENERATING
        new_image = await generate_scene_image(scene.image_prompt)
        scene.current_image_path = save_image(new_image)
        scene.status = ImageEditStatus.PENDING
    
    elif action == SceneEditAction.EDIT_PROMPT:
        scene.prompt_history.append(scene.image_prompt)
        scene.image_history.append(scene.current_image_path)
        scene.image_prompt = payload['modified_prompt']
        new_image = await generate_scene_image(scene.image_prompt)
        scene.current_image_path = save_image(new_image)
        scene.status = ImageEditStatus.PENDING
    
    elif action == SceneEditAction.UPLOAD_IMAGE:
        scene.image_history.append(scene.current_image_path)
        scene.current_image_path = save_uploaded_image(payload['file'])
        scene.status = ImageEditStatus.PENDING
    
    elif action == SceneEditAction.UNDO:
        if scene.image_history:
            scene.current_image_path = scene.image_history.pop()
            scene.status = ImageEditStatus.PENDING
    
    return scene
```

---

## 5. 프롬프트 수정 모달

[프롬프트 수정] 버튼 클릭 시 표시. 스타일/캐릭터 블록은 **읽기전용**(일관성 보호), 씬 설명/추가 지시만 편집 가능.

### 5.1 UI

```
┌─────────────────────────────────────────────────────────────────┐
│  ✏️ 장면 1 프롬프트 수정                                   [✕]  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ── 스타일 블록 (읽기전용) ───────────────────────────── 🔒    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Korean webtoon style, clean outlines...                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│  ⓘ 스타일 블록은 전체 일관성을 위해 수정할 수 없습니다         │
│                                                                 │
│  ── 캐릭터 블록 (읽기전용) ───────────────────────────── 🔒    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Character 1 - "고양이남편": white cat character...      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ── 씬 설명 (편집 가능) ──────────────────────────────── ✏️    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ 거실 배경, 하얀 고양이(남편)가 주먹을 불끈 쥐고 결의에  │   │
│  │ 찬 표정으로 서 있다. 그 옆에서 갈색 사슴(나)이 눈을     │   │
│  │ 동그랗게 뜨고 남편을 바라보는 모습.                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ── 추가 지시사항 (선택) ──────────────────────────────── ✏️   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ (예: 거실을 좀 더 넓게, 고양이 표정을 더 진지하게)       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ── 현재 vs 미리보기 ──                                         │
│  ┌────────────────┐    ┌────────────────┐                      │
│  │  현재 이미지    │    │  (미리보기)     │                      │
│  └────────────────┘    └────────────────┘                      │
│                                                                 │
│  [🔍 미리보기 (Low, ~$0.003)]  [🔄 재생성 (본 품질)]  [취소]    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 프롬프트 편집 데이터

```python
@dataclass
class PromptEditData:
    style_block: str          # 읽기전용
    character_block: str      # 읽기전용
    scene_description: str    # 편집 가능
    additional_notes: str     # 편집 가능
    locked_block: str         # 읽기전용
    exclusion_block: str      # 읽기전용
    
    def to_full_prompt(self) -> str:
        parts = [
            self.style_block,
            self.character_block,
            f"\n[THIS SCENE]\n{self.scene_description}",
            self.locked_block,
            self.exclusion_block,
        ]
        if self.additional_notes.strip():
            parts.append(f"\n[ADDITIONAL INSTRUCTIONS]\n{self.additional_notes}")
        return "\n".join(parts)
```

---

## 6. 단계 진행 규칙

- **모든 씬 ✓ 확정** → "다음: 텍스트 오버레이" 활성화
- 미확정 씬 있으면 → 버튼 비활성 + "N개 씬이 미확정입니다"
- 이전 단계로 돌아가면 → 전체 이미지 초기화 경고
- 톤 조절 적용된 이미지는 원본도 보존 (되돌리기 가능)
- 브라우저 닫아도 상태 자동 저장 (SQLite)

---

## 7. API 엔드포인트

```python
@router.get("/api/edit-stage/{project_id}")
async def get_edit_stage(project_id: str) -> ImageEditStage:
    """편집 단계 데이터 조회"""

@router.post("/api/edit-stage/{project_id}/tone-adjust")
async def apply_tone_adjustment(project_id: str, command: ToneCommand):
    """전체 톤 조절 적용"""

@router.post("/api/edit-stage/{project_id}/tone-reset")
async def reset_tone(project_id: str):
    """전체 톤 조절 원복"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/confirm")
async def confirm_scene(project_id: str, scene_num: int):
    """씬 확정"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/unconfirm")
async def unconfirm_scene(project_id: str, scene_num: int):
    """씬 확정 취소"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/regenerate")
async def regenerate_scene(project_id: str, scene_num: int):
    """같은 프롬프트로 재생성"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/edit-prompt")
async def edit_prompt_and_regenerate(project_id: str, scene_num: int, edit_data: PromptEditData):
    """프롬프트 수정 후 재생성"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/preview")
async def preview_prompt_edit(project_id: str, scene_num: int, edit_data: PromptEditData):
    """프롬프트 수정 미리보기 (Low 품질)"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/upload")
async def upload_custom_image(project_id: str, scene_num: int, file: UploadFile):
    """직접 이미지 업로드"""

@router.post("/api/edit-stage/{project_id}/scene/{scene_num}/undo")
async def undo_scene(project_id: str, scene_num: int):
    """이전 이미지로 되돌리기"""
```

---

## 8. 프론트엔드 컴포넌트 구조

```
ImageEditStage/
├── ToneAdjustmentPanel/       # 상단: 전체 톤 조절
│   ├── CommandInput           # 자연어 명령 입력
│   ├── QuickButtons           # 빠른 조절 버튼들
│   ├── TonePreview            # 전/후 미리보기
│   └── CostWarning            # AI 재생성 비용 경고
│
├── ProgressBar/               # 진행 상태 (N/M 확정)
│
├── SceneCardList/             # 씬 카드 목록
│   └── SceneCard/             # 개별 씬 카드
│       ├── SceneInfo          # 왼쪽: 나레이션, 대사, 프롬프트, 생성시간, [편집]
│       └── ImagePanel         # 오른쪽: 이미지 + [재생성][프롬프트수정][업로드][확정]
│
├── PromptEditModal/           # 프롬프트 수정 팝업
│   ├── ReadonlyBlock          # 스타일/캐릭터 (읽기전용 🔒)
│   ├── EditableBlock          # 씬설명/추가지시 (편집 가능 ✏️)
│   ├── ComparisonPreview      # 현재 vs 미리보기
│   └── ActionButtons          # [미리보기] [재생성] [취소]
│
└── NavigationBar/             # 하단: 이전/다음 단계
```

---

## 9. 기존 문서 업데이트 사항

### WORKFLOW.md

기존 Step 7 "이미지 검토 UI"를 "이미지 편집 단계"로 대체:

```
기존: ⑥ 이미지 생성 → ⑦ 이미지 검토 → ⑧ 텍스트 오버레이
변경: ⑥ 이미지 생성 → ⑦ 이미지 편집 ★ → ⑧ 텍스트 오버레이
```

### PRD_MASTER.md 워크플로우

```
→ [이미지 편집] (전체 톤 조절 + 씬별 확정) → [텍스트 오버레이] →
```

### DECISION_LOG.md

DEC-021: 이미지 편집 단계 신설 — 이미지 생성과 텍스트 오버레이 사이에 편집 단계 추가. 전체 톤 조절(무료 Pillow + 유료 AI 재생성 자동 구분), 씬별 확인/재생성/프롬프트 수정/업로드 기능.

---

## 변경 이력

| 날짜 | 버전 | 변경 내용 |
|------|------|----------|
| 2026-02-09 | 1.0.0 | 초기 작성 — 이미지 편집 단계 전체 설계 |
